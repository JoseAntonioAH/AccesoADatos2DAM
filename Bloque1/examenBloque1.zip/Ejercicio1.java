/*
 * ACCESO A DATOS - EXAMEN BLOQUE 1
 * EJERCICIO 1 - 2 puntos
 *
 * ENUNCIADO
 * Copia el contenido del fichero de texto "texto.txt" en un nuevo fichero de
 * texto llamado "texto_backup.txt", y muestra por pantalla cuantos caracteres
 * se han copiado.
 * 
 * REQUISITOS
 *  Los dos ficheros deben quedar cerrados al terminar el programa.
 *
 * EJEMPLO
 *  Si texto.txt contiene:
 *      Hola mundo, esto es una prueba de copia
 *  la salida del programa es:
 *      Hola Mundo, esto es una prueba de copia
        Se han copiado 39 caracteres
 *  y texto_backup.txt queda con el mismo texto que el fichero original.
 *
 * AYUDA
 *   Leer caracteres:              new FileReader(ruta)
 *   Escribir caracteres:          new FileWriter(ruta)
 */

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class Ejercicio1 {

    public static void main(String[] args) {
        

        try {
            File archivo1 = new File("texto.txt");
            File archivo2 = new File("texto_backup.txt");

            FileReader fr = new FileReader(archivo1);
            FileWriter fw = new FileWriter(archivo2);

            int data;
            int contador = 0;

            while((data=fr.read())>-1){
                //en el enunciado no pone que haya que mostrar el contenido por consola, 
                //pero en el ejemplo de salida lo pone. Lo pongo por si acaso
                System.out.print((char)data);
                fw.write(data);
                contador++;
            }

            fr.close();
            fw.close();

            System.out.println("\nSe han copiado "+contador+" caracteres");


        
        
        } catch (IOException e) {
            System.out.println("Error de E/S: " + e.getMessage());
        }

    }

}